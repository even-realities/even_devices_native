# Rebuild the beta.13 standalone SDK

Extract this archive and clone its self-contained source repository:

```sh
git clone native-sdk.bundle sdk
cd sdk
git rev-parse HEAD
git diff HEAD^ HEAD -- native/android/src/main/kotlin/com/fzfstudio
```

Compare HEAD with the source_commit in the Android and iOS build records. The parent commit contains retained upstream Android sources at their original revisions. The component references, upstream blobs, changes and binary codec inputs are documented in native/UPSTREAM_SOURCES.md and UPSTREAM_FILES.tsv. Kotlin, Swift, JNI/C, protocol fixtures and the exact codec build inputs are included.

With JDK 21, Android SDK 36, NDK and CMake as specified in native/android/build.gradle, Xcode 27 and Python 3.9+, start from the clean checkout:

```sh
export JAVA_HOME=$(/usr/libexec/java_home -v 21)
export ANDROID_HOME="$HOME/Library/Android/sdk"
export SDK_BUILD_NUMBER=13
export SDK_SOURCE_REPOSITORY='source/native-sdk-0.1.0-beta.13.tar.gz#native-sdk.bundle'
tool/package_native_sdk.sh 0.1.0-beta.13
```

Android dependencies resolve via the Gradle wrapper and configured Maven repositories. The output is under build/distribution/0.1.0-beta.13. The packaging entry points run the native tests and emit source and artifact hashes. Toolchain, timestamps and build paths can affect binary hashes.
